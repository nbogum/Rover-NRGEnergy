﻿namespace MarsRover.Models.Enums
{
    public enum CommandParams
    {
        M =1,
        L=2,
        R=3
    }
}
